config = {
    'db_path': 'your_path',
    'port': 5555
    }


def get_config():
    return config
