# Urban Infrastructure Improvement Project


Urban Infrastructure Improvement Project is a web app on top of aiohttp/asyncio. The project enables concerned citizens to leave and send complaints to local authorities. Every citizen may vote for other complaints to note the most relevant and important complaints. 



<img width="800" alt="Снимок экрана 2022-03-27 в 00 02 16" src="https://user-images.githubusercontent.com/30799388/160589839-8b817727-8377-4eb6-8b39-486ad955bca3.png">
